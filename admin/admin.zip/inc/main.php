





		<section>
				<div class="col-md-2">
					<div class="feature-box fbox-center fbox-outline fbox-effect nobottomborder">
						<div class="fbox-icon">
							<a href="new.php"><i class="icon-edit i-alt"></i></a>
						</div>
						<h3>New Post<span class="subtitle">Add A New Post</span></h3>
					</div>
				</div>
				<div class="col-md-2">
					<div class="feature-box fbox-center fbox-outline fbox-effect nobottomborder">
						<div class="fbox-icon">
							<a href="edit.php"><i class="icon-download i-alt"></i></a>
						</div>
						<h3>Edit Post<span class="subtitle">Make Changes to a Post</span></h3>
					</div>
				</div>

			
				<div class="col-md-2">
					<div class="feature-box fbox-center fbox-outline fbox-effect nobottomborder">
						<div class="fbox-icon">
							<a href="remove.php"><i class="icon-remove i-alt"></i></a>
						</div>
						<h3>Remove Post<span class="subtitle">Delete a Post</span></h3>
					</div>
				</div>

				<div class="col-md-2 col_last">
					<div class="feature-box fbox-center fbox-outline fbox-effect nobottomborder">
						<div class="fbox-icon">
							<a href="#"><i class="icon-settings i-alt"></i></a>
						</div>
						<h3>Settings<span class="subtitle">Manage Site Settings</span></h3>
					</div>
				</div>
		</section>

		