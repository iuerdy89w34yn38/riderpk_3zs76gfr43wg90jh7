<!-- Content
		============================================= -->
		<section>

			<div class="content-wrap" style="padding:30px">


					<div class="heading-block center" >
						<h1>Welcome <?php echo $_SESSION['name'];?></h1>
						<span>Lets Start...</span>
					</div>

					
				</div>

			</div>
		</section>
	