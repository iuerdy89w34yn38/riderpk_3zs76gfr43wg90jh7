<?php 
	include('secure.php');
	?>
<html>
	<head>
	<title>Insert New Post</title>
	
		<link type="text/css" rel="stylesheet" href="../css/style.css">
		
		
	</head>
	
<body>
	<center>
	<br><br><br><br>
	<div class="insert_box">
	<br><br><br><br>
	<div class="a">
	<a href="insert_cars.php" >Insert Car Post </a>
	</div>
	<br><br><br><br>
	
	<div class="b">
	<a href="insert_bikes.php" >Insert Bike Post </a>
	</div>
	
	
	
	
	
	
	
	
	
	</div>