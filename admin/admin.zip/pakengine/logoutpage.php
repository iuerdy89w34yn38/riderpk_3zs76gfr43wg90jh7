Are you sure you want to logout?
<a href="logout.php">Lougout</a>