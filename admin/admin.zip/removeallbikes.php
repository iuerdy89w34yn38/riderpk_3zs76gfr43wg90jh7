<?php 

header("Location:removeallcars.php");
?>