<html>
	<head>
	
	
	<?php include('inc/head.php'); ?>
	
	<title>Welcome <?php echo $_SESSION['name'];?></title>

	
	</head>

<body class="stretched">

<!-- Document Wrapper
	============================================= -->
	<div id="wrapper" class="clearfix">
	
	
	<?php  
	
	 $id = $_GET['carid'];
	echo $id;
	
	 ?>
	
	
	<form method="post" action="editcardespdone.php?carid=<?php echo "$id"; ?>" enctype="multipart/form-data">
	
	<!-- Content
		============================================= -->
		<section id="">

			<div class="content-wrap">

				<div class="container" style="margin-right:none;">
				
				<?php 
	$rows=mysqli_query($con,"select * from carposts where post_id = '$id'")or die(mysql_error());
	
	while($row=mysqli_fetch_array($rows)){
		
		$pmaxl = $row['pmaxl'];
		$pmaxt = $row['pmaxt'];
		$pminl = $row['pminl'];
		$pmint = $row['pmint'];
		$sdesp = $row['sdesp'];
		$desp = $row['desp'];
		$inter = $row['inter'];
		$exter = $row['exter'];
		$millage = $row['millage'];
		$engine = $row['engine'];
		$gearbox = $row['gearbox'];
		
		
	}	
	
	
	
	
		?>

					<!-- Post Content
					============================================= -->
					<div class=" nobottommargin clearfix">
						<div class="row">
							
							
						<div class="row">
						
						<div class="col-md-6" >
						<h4> Price Max </h4>
						
							<div class="col-md-3 bottommargin-sm">
								
								<textarea class="required sm-form-control" id="" name="pmaxl" rows="1" ><?php echo "$pmaxl" ; ?></textarea>
							
								
							</div>
							<div class="col-md-2 topmargin-sm">
								
								<label for="">Lac</label>
								
							</div>
							
							<div class="col-md-3 bottommargin-sm">
								
								<textarea class="required sm-form-control" id="" name="pmaxt" rows="1" cols="10"><?php echo "$pmaxt" ; ?></textarea>
								
							</div>
							<div class="col-md-2 topmargin-sm">
								
								<label for="">Thousands</label>
								
							</div>
							
							</div>
							
							
							<div class="col-md-6" >
							
							<h4> Price Min </h4>
							
							<div class="col-md-3 bottommargin-sm">
								
								<textarea class="required sm-form-control" id="" name="pminl" rows="1" ><?php echo "$pminl" ; ?></textarea>
							
								
							</div>
							<div class="col-md-2 topmargin-sm">
								
								<label for="">Lac</label>
								
							</div>
							
							<div class="col-md-3 bottommargin-sm">
								
								<textarea class="required sm-form-control" id="" name="pmint" rows="1" cols="10"><?php echo "$pmint" ; ?></textarea>
								
							</div>
							<div class="col-md-2 topmargin-sm">
								
								<label for="">Thousands</label>
								
							</div>
							
							</div>
							
						</div>
							
							
							<div class="col-md-6 bottommargin-sm">
									<label for="template-contactform-message">Short Description <small>*</small></label>
									<textarea class="required sm-form-control" id="" name="sdesp" rows="4" cols="30"><?php echo "$sdesp" ; ?></textarea>
								</div>
								<br>
							
							<div class="bottommargin hidden-lg hidden-md"></div>
							
						</div>
						<div class="row">	
							
						
							<div class="col-md-8 bottommargin-sm">
									<label for="template-contactform-message">Long Description <small>*</small></label>
									<textarea class="required sm-form-control" id="" name="desp" rows="6" cols="30"><?php echo "$desp" ; ?></textarea>
								</div>
								
								
							
						</div>
						<div class="row">	
							
							
							

							<div class="col-md-6 bottommargin-sm">
									<label for="">Interior <small>*</small></label>
									<textarea class="required sm-form-control" id="" name="inter" rows="6" cols="30"><?php echo "$inter" ; ?></textarea>
								</div>

							
							<div class="col-md-6 bottommargin-sm">
									<label for="template-contactform-message">Exterior <small>*</small></label>
									<textarea class="required sm-form-control" id="" name="exter" rows="6" cols="30"><?php echo "$exter" ; ?></textarea>
								</div>
								
						</div>
						<div class="row">	
						
							<div class="col-md-4 bottommargin-sm">
								<label for="">Engine <small>*</small></label>
								<textarea class="required sm-form-control" id="" name="engine" rows="2" cols="30"><?php echo "$engine" ; ?></textarea>
							</div>
							<div class="col-md-4 bottommargin-sm">
								<label for="">Millage <small>*</small></label>
								<textarea class="required sm-form-control" id="" name="millage" rows="2" cols="30"><?php echo "$millage" ; ?></textarea>
							</div>
							<div class="col-md-4 bottommargin-sm">
								<label for="">Gearbox <small>*</small></label>
								<textarea class="required sm-form-control" id="" name="gearbox" rows="2" cols="30"><?php echo "$gearbox" ; ?></textarea>
							</div>
							
						</div>
						<div class="bottommargin hidden-lg hidden-md"></div>
							
					</div><!-- .postcontent end -->


				</div>

			</div>

		</section><!-- #content end -->
	
	
	
	
	
	
	
	
	
	
		
		
		
		
		
		
		
		
				
<div class="twoToneCenter">
    
    <button name="submit" class="twoToneButton">Update</button>
    
</div>

<br><br><br><br><br><br><br><br>
	
	















	<!-- Go To Top
	============================================= -->
	<div id="gotoTop" class="icon-angle-up"></div>
	
	<!-- External JavaScripts
	============================================= -->
	<script type="text/javascript" src="../js/jquery.js"></script>
	<script type="text/javascript" src="../js/plugins.js"></script>

	

	<!-- Footer Scripts
	============================================= -->
	<script type="text/javascript" src="../js/functions.js"></script>

	<script  type="text/javascript">
				
		$(function(){
    
    var twoToneButton = document.querySelector('.twoToneButton');
    
    twoToneButton.addEventListener("click", function() {
        twoToneButton.innerHTML = "Updating (Please Wait...)";
        
      setTimeout( 
            function  (){  
                twoToneButton.innerHTML = "Posted";
                
            }, 600000);
    }, false);
    
	});

	</script>

</body>
</html>





